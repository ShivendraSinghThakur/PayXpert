package com.java.PayXpert;

import static org.junit.Assert.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.junit.Test;

import com.java.PayXpert.model.Finance;

public class FinanceTest {

	@Test
	public void testConstructors() throws ParseException {
		SimpleDateFormat sdf= new SimpleDateFormat("dd/MM/yyyy");
		Finance f= new Finance();
		assertNotNull(f);
		Finance f1 = new Finance(1, 1, sdf.parse("01/04/2024"), "Salary", 50000, "Income");
	}

	@Test
	public void testGettersSetters() throws ParseException {
		SimpleDateFormat sdf= new SimpleDateFormat("dd/MM/yyyy");
		Finance f= new Finance();
		f.setRecordID(1);
		f.setEmployeeID(1);
		f.setRecordDate(sdf.parse("01/04/2024"));
		f.setDescription("Salary");
		f.setAmount(50000);
		f.setRecordType("Income");
		assertEquals(1,f.getRecordID());
		assertEquals(1,f.getEmployeeID());
		assertEquals(sdf.parse("01/04/2024"),f.getRecordDate());
		assertEquals("Salary",f.getDescription());
		assertEquals(50000,f.getAmount(),0);
		assertEquals("Income",f.getRecordType());
	}
	
	@Test
	public void testHashCode() throws ParseException {
		SimpleDateFormat sdf= new SimpleDateFormat("dd/MM/yyyy");
		Finance f1 = new Finance(1, 1, sdf.parse("01/04/2024"), "Salary", 50000, "Income");
		Finance f2 = new Finance(1, 1, sdf.parse("01/04/2024"), "Salary", 50000, "Income");
		assertEquals(f1.hashCode(), f2.hashCode());
	}
	
	@Test
	public void testEquals() throws ParseException {
		SimpleDateFormat sdf= new SimpleDateFormat("dd/MM/yyyy");
		Finance f1 = new Finance(1, 1, sdf.parse("01/04/2024"), "Salary", 50000, "Income");
		Finance f2 = new Finance(1, 1, sdf.parse("01/04/2024"), "Salary", 50000, "Income");
		Finance f3 = new Finance(1, 2, sdf.parse("01/04/2024"), "Salary", 50000, "Income");
		assertTrue(f1.equals(f2));
		assertFalse(f1.equals(f3));
	}
	
	@Test
	public void testToString() throws ParseException {
		SimpleDateFormat sdf= new SimpleDateFormat("dd/MM/yyyy");
		Finance f1 = new Finance(1, 1, sdf.parse("01/04/2024"), "Salary", 50000, "Income");
		String result = "Finance [recordID=1, employeeID=1, recordDate=Mon Apr 01 00:00:00 IST 2024, description=Salary, amount=50000.0, recordType=Income]";
		assertEquals(f1.toString(), result);
	}
}

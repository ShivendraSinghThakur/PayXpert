package com.java.PayXpert;

import static org.junit.Assert.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.junit.Test;

import com.java.PayXpert.model.Employee;

public class EmployeeTest {
	
	@Test
	public void testDefaultConstructor() {
		Employee employee = new Employee();
		assertNotNull(employee);
	}

	@Test
	public void testContructors() throws ParseException {
		Employee employee = new Employee();
		assertNotNull(employee);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Employee emp = new Employee(1, "Shivendra", "Thakur", sdf.parse("2002-03-26"), 
				"Male", "qwerty@example.com","9911111111", "Indore", 
				"Software Engineer", "2020-01-10", sdf.parse("2020-05-22"));
	}
		
	
	@Test
	public void testGettersSetters() throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Employee employee=new Employee();
		employee.setEmployeeId(1);
		employee.setFirstName("Shivendra");
		employee.setLastName("Thakur");
		employee.setDob(sdf.parse("26/03/2002"));
		employee.setGender("Male");
		employee.setEmail("qwerty@example.com");
		employee.setPhoneNumber("9911111111");
		employee.setAddress("Indore");
		employee.setPosition("Software Engineer");
		employee.setJoiningDate("10/01/2020");
		employee.setTerminationDate(sdf.parse("22/05/2020"));
		
		assertEquals(1, employee.getEmployeeId());
		assertEquals("Shivendra", employee.getFirstName());
		assertEquals("Thakur", employee.getLastName());
		assertEquals(sdf.parse("26/03/2002"), employee.getDob());
		assertEquals("Male", employee.getGender());
		assertEquals("qwerty@example.com", employee.getEmail());
		assertEquals("9911111111", employee.getPhoneNumber());
		assertEquals("Indore", employee.getAddress());
		assertEquals("Software Engineer", employee.getPosition());
		assertEquals("10/01/2020", employee.getJoiningDate());
		assertEquals(sdf.parse("22/05/2020"), employee.getTerminationDate());
	}
	
	@Test
	public void testHashCode() throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Employee emp1 = new Employee(1, "Shivendra", "Thakur", sdf.parse("26/03/2002"), 
				"Male", "qwerty@example.com","9911111111", "Indore", 
				"Software Engineer", "2020-01-10", sdf.parse("22/05/2020"));
		Employee emp2 = new Employee(1, "Shivendra", "Thakur", sdf.parse("26/03/2002"), 
				"Male", "qwerty@example.com","9911111111", "Indore", 
				"Software Engineer", "2020-01-10", sdf.parse("22/05/2020"));
		assertEquals(emp1.hashCode(), emp2.hashCode());
	}
	
	@Test
	public void testEquals() throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Employee emp1 = new Employee(1, "Shivendra", "Thakur", sdf.parse("26/03/2002"), 
				"Male", "qwerty@example.com","9911111111", "Indore", 
				"Software Engineer", "2020-01-10", sdf.parse("22/05/2020"));
		Employee emp2 = new Employee(1, "Shivendra", "Thakur", sdf.parse("26/03/2002"), 
				"Male", "qwerty@example.com","9911111111", "Indore", 
				"Software Engineer", "2020-01-10", sdf.parse("22/05/2020"));
		Employee emp3 = new Employee(1, "Shivendra", "Thakur", sdf.parse("26/03/2002"), 
				"Male", "qwerty@example.com","9911111111", "Indore", 
				"Software Engineer", "2020-01-10", sdf.parse("22/05/2021"));
		assertTrue(emp1.equals(emp2));
		assertFalse(emp1.equals(emp3));
	}
	
	@Test
	public void testToString() throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Employee emp1 = new Employee(1, "Shivendra", "Thakur", sdf.parse("26/03/2002"), 
				"Male", "qwerty@example.com","9911111111", "Indore", 
				"Software Engineer", "2020-01-10", sdf.parse("22/05/2020"));
		String result = "Employee [employeeID=1, firstName=Shivendra, lastName=Thakur, dob=Tue Mar 26 00:00:00 IST 2002, "
				+ "gender=Male, email=qwerty@example.com, phoneNumber=9911111111, address=Indore, position=Software Engineer, "
				+ "joiningDate=2020-01-10, terminationDate=Fri May 22 00:00:00 IST 2020]";
		assertEquals(emp1.toString(), result);
	}
	

}

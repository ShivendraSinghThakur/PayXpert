package com.java.PayXpert;

import static org.junit.Assert.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.junit.Test;

import com.java.PayXpert.model.Payroll;

public class PayrollTest {

	@Test
	public void testConstructors() throws ParseException {
		Payroll p = new Payroll();
		assertNotNull(p);
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Payroll p1 = new Payroll(1, 1, sdf.parse("26/03/2020"),sdf.parse("26/04/2020"),
					50000,3000,1000,52000);
	}

	@Test
	public void testGettersSetters() throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Payroll p = new Payroll();
		p.setPayrollID(1);
		p.setEmployeeID(1);
		p.setPayPeriodStartDate(sdf.parse("26/03/2020"));
		p.setPayPeriodEndDate(sdf.parse("26/04/2020"));
		p.setBasicSalary(50000);
		p.setOvertimePay(3000);
		p.setDeductions(1000);
		p.setNetSalary(52000);			
		assertEquals(1, p.getPayrollID());
		assertEquals(1,p.getEmployeeID());
		assertEquals(sdf.parse("26/03/2020"),p.getPayPeriodStartDate());
		assertEquals(sdf.parse("26/04/2020"),p.getPayPeriodEndDate());
		assertEquals(50000,p.getBasicSalary(),0);
		assertEquals(3000, p.getOvertimePay(),0);
		assertEquals(1000,p.getDeductions(),0);
		assertEquals(52000,p.getNetSalary(),0);
	}
	
	@Test
	public void testHashCode() throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Payroll p1 = new Payroll(1, 1, sdf.parse("26/03/2020"),sdf.parse("26/04/2020"),50000,3000,1000,52000);
		Payroll p2 = new Payroll(1, 1, sdf.parse("26/03/2020"),sdf.parse("26/04/2020"),50000,3000,1000,52000);
		assertEquals(p1.hashCode(), p2.hashCode());
	}
	
	@Test
	public void testEquals() throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Payroll p1 = new Payroll(1, 1, sdf.parse("26/03/2020"),sdf.parse("26/04/2020"),50000,3000,1000,52000);
		Payroll p2 = new Payroll(1, 1, sdf.parse("26/03/2020"),sdf.parse("26/04/2020"),50000,3000,1000,52000);
		Payroll p3 = new Payroll(1, 1, sdf.parse("26/02/2020"),sdf.parse("26/04/2020"),50000,3000,1000,52000);
		assertTrue(p1.equals(p2));
		assertFalse(p1.equals(p3));
	}
	
	@Test
	public void testToString() throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Payroll p1 = new Payroll(1, 1, sdf.parse("26/03/2020"),sdf.parse("26/04/2020"),50000,3000,1000,52000);
		String result = "Payroll [payrollID=1, employeeID=1, payPeriodStartDate=Thu Mar 26 00:00:00 IST 2020, payPeriodEndDate=Sun Apr 26 00:00:00 IST 2020, basicSalary=50000.0, overtimePay=3000.0, deductions=1000.0, netSalary=52000.0]";
		assertEquals(p1.toString(), result);
	}
}

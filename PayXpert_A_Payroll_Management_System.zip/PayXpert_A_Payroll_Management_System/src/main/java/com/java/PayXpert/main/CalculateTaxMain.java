package com.java.PayXpert.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.PayXpert.dao.TaxService;

public class CalculateTaxMain {

	public static void main(String[] args) {
		int employeeId;
		String year;
		
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter employeeID ");
		employeeId = sc.nextInt();
		System.out.println("Enter TaxYear..");
		year = sc.next();
		TaxService t =new TaxService();
		double a = -1;
		
		try {
			a = t.CalculateTax(employeeId, year);
			if (a == -1)
			{
				System.out.println("Record Not Found");
			}
			else {
			System.out.println("Taxamount " + a);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

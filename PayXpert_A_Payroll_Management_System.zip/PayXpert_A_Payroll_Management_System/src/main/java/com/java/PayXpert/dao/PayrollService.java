package com.java.PayXpert.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.java.PayXpert.model.Payroll;
import com.java.PayXpert.util.DBConnUtil;
import com.java.PayXpert.util.DBPropertyUtil;

public class PayrollService implements IPayrollService{

	Connection connection;
	PreparedStatement pst;
	
	//@Override
	//void generatePayroll(int employeeID, Date startDate, Date endDate) throws ClassNotFoundException, SQLException {
		
	//}

	@Override
	public Payroll getPayrollById(int payrollID) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		
		String cmd = "SELECT * FROM Payroll WHERE PayrollID = ?";
		
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, payrollID);
		
		ResultSet rs = pst.executeQuery();
		
		Payroll payroll = null;
		
		if(rs.next()) {
			payroll = new Payroll();
			payroll.setPayrollID(rs.getInt("PayrollID"));
			payroll.setEmployeeID(rs.getInt("EmployeeID"));
			payroll.setPayPeriodStartDate(rs.getDate("PayPeriodStartDate"));
			payroll.setPayPeriodEndDate(rs.getDate("PayPeriodEndDate"));
			payroll.setBasicSalary(rs.getDouble("BasicSalary"));
			payroll.setOvertimePay(rs.getDouble("OvertimePay"));
			payroll.setDeductions(rs.getDouble("Deductions"));
			payroll.setNetSalary(rs.getDouble("NetSalary"));
		}
		return payroll;
	}

	@Override
	public List<Payroll> getPayrollsForEmployee(int employeeID) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		
		String cmd = "SELECT * FROM Payroll WHERE EmployeeID = ?";
		
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, employeeID);
		
		ResultSet rs = pst.executeQuery();
		
		List<Payroll> payrollList = new ArrayList<Payroll>();
		Payroll payroll = null;
		
		if(rs.next()) {
			payroll = new Payroll();
			payroll.setPayrollID(rs.getInt("PayrollID"));
			payroll.setEmployeeID(rs.getInt("EmployeeID"));
			payroll.setPayPeriodStartDate(rs.getDate("PayPeriodStartDate"));
			payroll.setPayPeriodEndDate(rs.getDate("PayPeriodEndDate"));
			payroll.setBasicSalary(rs.getDouble("BasicSalary"));
			payroll.setOvertimePay(rs.getDouble("OvertimePay"));
			payroll.setDeductions(rs.getDouble("Deductions"));
			payroll.setNetSalary(rs.getDouble("NetSalary"));
			payrollList.add(payroll);
		}
		return payrollList;
	}

	@Override
	public List<Payroll> getPayrollsForPeriod(Date payPeriodStartDate, Date payPeriodEndDate)
			throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		
		String cmd = "SELECT * FROM Payroll WHERE PayPeriodStartDate >= ? AND PayPeriodEndDate <= ?";
		
		pst = connection.prepareStatement(cmd);
		
		pst.setDate(1, new java.sql.Date(payPeriodStartDate.getTime()));
        pst.setDate(2, new java.sql.Date(payPeriodEndDate.getTime()));
		
		ResultSet rs = pst.executeQuery();
		
		List<Payroll> payrolls = new ArrayList<Payroll>();
		Payroll payroll = null;
		
		while(rs.next()) {
			payroll = new Payroll();
			payroll.setPayrollID(rs.getInt("PayrollID"));
			payroll.setEmployeeID(rs.getInt("EmployeeID"));
			payroll.setPayPeriodStartDate(rs.getDate("PayPeriodStartDate"));
			payroll.setPayPeriodEndDate(rs.getDate("PayPeriodEndDate"));
			payroll.setBasicSalary(rs.getDouble("BasicSalary"));
			payroll.setOvertimePay(rs.getDouble("OvertimePay"));
			payroll.setDeductions(rs.getDouble("Deductions"));
			payroll.setNetSalary(rs.getDouble("NetSalary"));
			payrolls.add(payroll);
		}
		return payrolls;
	}

	@Override
	public List<Payroll> generatePayroll(int employeeID, Date startDate, Date endDate)
			throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		
		
		String cmd = "SELECT * FROM Payroll WHERE EmployeeID= ? AND PayPeriodStartDate=? AND PayPeriodEndDate=? ";
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, employeeID);
		pst.setDate(2, new java.sql.Date(startDate.getTime()));
		pst.setDate(3, new java.sql.Date(endDate.getTime()));
		
		ResultSet rs = pst.executeQuery();
		
		List<Payroll> payrollsList = new ArrayList<Payroll>();
		Payroll payroll = null;
		
		while(rs.next()) {
			payroll = new Payroll();
			payroll.setPayrollID(rs.getInt("PayrollID"));
			payroll.setEmployeeID(rs.getInt("EmployeeID"));
			payroll.setPayPeriodStartDate(rs.getDate("PayPeriodStartDate"));
			payroll.setPayPeriodEndDate(rs.getDate("PayPeriodEndDate"));
			payroll.setBasicSalary(rs.getDouble("BasicSalary"));
			payroll.setOvertimePay(rs.getDouble("OvertimePay"));
			payroll.setDeductions(rs.getDouble("Deductions"));
			payroll.setNetSalary(rs.getDouble("NetSalary"));
			payrollsList.add(payroll);
		}
		return payrollsList;
	}

}

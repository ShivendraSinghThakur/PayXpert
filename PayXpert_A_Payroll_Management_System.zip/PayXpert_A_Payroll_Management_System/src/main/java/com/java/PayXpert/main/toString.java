package com.java.PayXpert.main;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.java.PayXpert.model.Employee;
import com.java.PayXpert.model.Finance;
import com.java.PayXpert.model.Payroll;
import com.java.PayXpert.model.Tax;

public class toString {

	public static void main(String[] args) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Employee e = new Employee(1, "Shivendra", "Thakur", sdf.parse("26/03/2002"), "Male", "qwerty@example.com", "9911111111", "Indore", "Software Engineer", "18-02-2021", sdf.parse("28-04-2022"));
		System.out.println(e.toString());
		
		Payroll p = new Payroll(1, 1, sdf.parse("26/03/2020"),sdf.parse("26/04/2020"),50000,3000,1000,52000);
		System.out.println(p.toString());
		
		Tax t = new Tax(1, 1, "2020", 44500,7500 );
		System.out.println(t.toString());
		
		Finance f1 = new Finance(1, 1, sdf.parse("01/04/2024"), "Salary", 50000, "Income");
		System.out.println(f1.toString());
	}
}

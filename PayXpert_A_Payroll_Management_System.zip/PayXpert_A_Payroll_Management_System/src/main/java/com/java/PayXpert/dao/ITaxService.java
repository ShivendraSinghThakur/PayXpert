package com.java.PayXpert.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.PayXpert.model.Tax;

public interface ITaxService {

	public double CalculateTax(int employeeId, String taxyear) throws ClassNotFoundException, SQLException;
    public double getTaxById(int taxID) throws ClassNotFoundException, SQLException;
    List<Tax> getTaxesForEmployee(int employeeID) throws ClassNotFoundException, SQLException;
    List<Tax> getTaxesForYear(String year) throws ClassNotFoundException, SQLException;
}

package com.java.PayXpert.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.PayXpert.dao.FinancialRecordService;

public class AddFinancialRecordMain {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter EmployeeID  ");
		int employeeID = sc.nextInt();
		
		System.out.println("Enter description  ");
		String description = sc.next();
		
		System.out.println("Enter amount  ");
		double amount = sc.nextDouble();
		
		System.out.println("Enter recordType ");
		String recordType = sc.next();
		
		FinancialRecordService f = new FinancialRecordService();
		try {
			String s = f.addFinancialRecord(employeeID, description, amount, recordType);
			System.out.println(s);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

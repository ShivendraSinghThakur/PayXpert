package com.java.PayXpert.dao;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import com.java.PayXpert.model.Finance;

public interface IFinancialRecordService {

	String addFinancialRecord(int employeeID, String description, double amount, String recordType) throws ClassNotFoundException, SQLException;
    Finance getFinancialRecordById(int recordID) throws ClassNotFoundException, SQLException;
    List<Finance> getFinancialRecordsForEmployee(int employeeID) throws ClassNotFoundException, SQLException;
    List<Finance> getFinancialRecordsForDate(Date recordDate) throws ClassNotFoundException, SQLException;
}

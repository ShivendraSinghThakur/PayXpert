package com.java.PayXpert.main;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.java.PayXpert.dao.PayrollService;
import com.java.PayXpert.model.Payroll;

public class GetPayrollsByPeriodMain {

	public static void main(String[] args) throws ParseException {
		int employeeId;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee payrollStartDate  ");
		String dateStr = sc.next();
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");  
		Date startdate = sdf.parse(dateStr);
		
		System.out.println("Enter employee payroll enddate..");
		String dateStr1 = sc.next();  
		
		Date enddate = sdf.parse(dateStr1);
		
		PayrollService p = new PayrollService();
		List<Payroll> payrollList;
		
		try {
			payrollList=p.getPayrollsForPeriod(startdate,enddate);
			if(payrollList != null) {
				for (Payroll payroll : payrollList) {
					System.out.println(payroll);
				}
			}
			if(payrollList.size() == 0) {
				System.out.println("Records Not Found");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

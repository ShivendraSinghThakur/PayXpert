package com.java.PayXpert.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.java.PayXpert.model.Employee;
import com.java.PayXpert.util.DBConnUtil;
import com.java.PayXpert.util.DBPropertyUtil;

public class EmployeeService implements IEmployeeService {

	Connection connection;
	PreparedStatement pst;
	
	@Override
	public Employee getEmployeeById(int employeeID) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		
		String cmd = "SELECT * FROM Employee WHERE EmployeeID = ?";
		
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, employeeID);
		
		ResultSet rs = pst.executeQuery();
		
		Employee employee = null;
		
		if(rs.next()) {
			employee = new Employee();
			employee.setEmployeeId(rs.getInt("EmployeeID"));
			employee.setFirstName(rs.getString("FirstName"));
			employee.setLastName(rs.getString("LastName"));
			employee.setDob(rs.getDate("Dob"));
			employee.setGender(rs.getString("Gender"));
			employee.setEmail(rs.getString("Email"));
			employee.setPhoneNumber(rs.getString("PhoneNumber"));
			employee.setAddress(rs.getString("Address"));
			employee.setPosition(rs.getString("Position"));
			employee.setJoiningDate(rs.getString("JoiningDate"));
			employee.setTerminationDate(rs.getDate("TerminationDate"));
		}
		return employee;
	}

	@Override
	public List<Employee> getAllEmployees() throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		
		String cmd = "SELECT * FROM Employee";
		
		pst = connection.prepareStatement(cmd);
		
		ResultSet rs = pst.executeQuery();
		
		List<Employee> employeeList = new ArrayList<Employee>();
		Employee employee = null;
		
		while(rs.next()) {
			employee = new Employee();
			employee.setEmployeeId(rs.getInt("EmployeeID"));
			employee.setFirstName(rs.getString("FirstName"));
			employee.setLastName(rs.getString("LastName"));
			employee.setDob(rs.getDate("Dob"));
			employee.setGender(rs.getString("Gender"));
			employee.setEmail(rs.getString("Email"));
			employee.setPhoneNumber(rs.getString("PhoneNumber"));
			employee.setAddress(rs.getString("Address"));
			employee.setPosition(rs.getString("Position"));
			employee.setJoiningDate(rs.getString("JoiningDate"));
			employee.setTerminationDate(rs.getDate("TerminationDate"));
			employeeList.add(employee);
		}
		return employeeList;
	}

	@Override
	public String addEmployee(Employee employee) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		
		String cmd = "INSERT INTO Employee (EmployeeID, FirstName, LastName, Dob, "
				+ "Gender, Email, PhoneNumber, Address, Position, JoiningDate, TerminationDate) "
				+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		
		pst = connection.prepareStatement(cmd);
		
		pst.setInt(1, employee.getEmployeeId());
		pst.setString(2, employee.getFirstName());
        pst.setString(3, employee.getLastName());
        pst.setDate(4, new java.sql.Date(new java.util.Date().getTime()));
        pst.setString(5, employee.getGender());
        pst.setString(6, employee.getEmail());
        pst.setString(7, employee.getPhoneNumber());
        pst.setString(8, employee.getAddress());
        pst.setString(9, employee.getPosition());
        pst.setDate(10, new java.sql.Date(new java.util.Date().getTime()));
        pst.setDate(11, employee.getTerminationDate() != null ? new java.sql.Date(employee.getTerminationDate().getTime()) : null);
		pst.executeUpdate();
		return "Employee Added Successfully";
	}

	@Override
	public String updateEmployee(Employee employee) throws ClassNotFoundException, SQLException {
		Employee employFound = getEmployeeById(employee.getEmployeeId());
		if(employFound != null) {
			String connStr = DBPropertyUtil.connectionString("db");
			connection = DBConnUtil.getConnection(connStr);
			
			String cmd = "UPDATE Employee SET FirstName = ?, LastName = ?, "
					+ "Dob = ?, Gender = ?, Email = ?, PhoneNumber = ?, Address = ?, "
					+ "Position = ?, JoiningDate = ?, TerminationDate = ? WHERE EmployeeID = ?";
			
			pst = connection.prepareStatement(cmd);
			
			pst.setString(1, employee.getFirstName());
	        pst.setString(2, employee.getLastName());
	        pst.setDate(3, new java.sql.Date(new java.util.Date().getTime()));
	        pst.setString(4, employee.getGender());
	        pst.setString(5, employee.getEmail());
	        pst.setString(6, employee.getPhoneNumber());
	        pst.setString(7, employee.getAddress());
	        pst.setString(8, employee.getPosition());
	        pst.setDate(9, new java.sql.Date(new java.util.Date().getTime()));
	        pst.setDate(10, employee.getTerminationDate() != null ? new java.sql.Date(employee.getTerminationDate().getTime()) : null);
	        pst.setInt(11, employee.getEmployeeId());
	        pst.executeUpdate();
	        return "Employee Record Updated.";
		}
		return "Employee Record Not Found";
	}
		

	@Override
	public String removeEmployee(int employeeID) throws ClassNotFoundException, SQLException {
		Employee employFound = getEmployeeById(employeeID);
		if(employFound != null) {
			String connStr = DBPropertyUtil.connectionString("db");
			connection = DBConnUtil.getConnection(connStr);
			
			String cmd = "DELETE FROM Employee WHERE EmployeeID = ?";
			
			pst = connection.prepareStatement(cmd);
			pst.setInt(1,  employeeID);
			pst.executeUpdate();
			return "Employee Record Deleted";
		}
		return "Employ Record Not Found";
	}

	public int CalculateAge(Date dob) {
		LocalDate date = dob.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate currentDate = LocalDate.now(); 
        Period period = Period.between(date, currentDate); 
        return period.getYears(); 
	}

}

package com.java.PayXpert.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class AddEmployeeMain {

	public static void main(String[] args) throws ParseException {
		int employeeID;
		String firstName, lastName, gender, email, phoneNumber, address, position, joiningDate;
		Date dob, terminationDate;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter EmployeeID:  ");
		employeeID = sc.nextInt();
		
		System.out.println("Enter FirstName:  ");
		firstName = sc.next();
		
		System.out.println("Enter LastName:  ");
		lastName = sc.next();
		
		System.out.println("Enter Dob (dd/MM/yyyy):  ");
		String dateStr = sc.next();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		dob = sdf.parse(dateStr);
		
		System.out.println("Enter Gender:  ");
		gender = sc.next();
		
		System.out.println("Enter Email:  ");
		email = sc.next();
		
		System.out.println("Enter PhoneNumber:  ");
		phoneNumber = sc.next();
		
		System.out.println("Enter Address:  ");
		address = sc.next();
		
		System.out.println("Enter Position:  ");
		position = sc.next();
		
		System.out.println("Enter JoiningDate(dd/MM/yyyy):  ");
		joiningDate = sc.next();
		
		System.out.println("Enter TerminationDate(dd/MM/yyyy, leave blank if not applicable):  ");
		String terminationDateStr = sc.next();
		terminationDate = null;
		if (!terminationDateStr.isEmpty()) {
            terminationDate = sdf.parse(terminationDateStr);
        }
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/payxpert", 
					"root", "india@123");
			
			String cmd = "INSERT INTO Employee (EmployeeID, FirstName, LastName, Dob, "
					+ "Gender, Email, PhoneNumber, Address, Position, JoiningDate, TerminationDate) "
					+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			
			PreparedStatement pst = connection.prepareStatement(cmd);
			
			pst.setInt(1, employeeID);
			pst.setString(2, firstName);
	        pst.setString(3, lastName);
	        pst.setDate(4, new java.sql.Date(dob.getTime()));
	        pst.setString(5, gender);
	        pst.setString(6, email);
	        pst.setString(7, phoneNumber);
	        pst.setString(8, address);
	        pst.setString(9, position);
	        pst.setString(10, joiningDate);
	        if (terminationDate != null) {
                pst.setDate(11, new java.sql.Date(terminationDate.getTime()));
            } else {
                pst.setNull(11, java.sql.Types.DATE);
            }
	        pst.executeUpdate();
			System.out.println("Employee Added Successfully"); 
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
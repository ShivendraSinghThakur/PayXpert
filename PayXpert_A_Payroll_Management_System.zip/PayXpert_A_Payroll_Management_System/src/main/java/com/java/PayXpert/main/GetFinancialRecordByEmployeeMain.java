package com.java.PayXpert.main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.java.PayXpert.dao.FinancialRecordService;
import com.java.PayXpert.model.Finance;

public class GetFinancialRecordByEmployeeMain {

	public static void main(String[] args) {
		List<Finance> finList = null;
		FinancialRecordService f= new FinancialRecordService();
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter employeeID  ");
		int employeeId = sc.nextInt();
		
		try {
			finList = f.getFinancialRecordsForEmployee(employeeId);
			if(finList!=null)
			{
				for (Finance financialRecord : finList) {
					System.out.println(financialRecord);
				}
			}
			if(finList.size()==0)
			{
				System.out.println("Record not found");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

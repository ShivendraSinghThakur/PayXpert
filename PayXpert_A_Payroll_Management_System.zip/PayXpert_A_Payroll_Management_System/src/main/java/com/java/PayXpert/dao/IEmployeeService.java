package com.java.PayXpert.dao;

import java.sql.SQLException;
import java.util.List;

import com.java.PayXpert.model.Employee;

public interface IEmployeeService {

	Employee getEmployeeById(int employeeID) throws ClassNotFoundException, SQLException;
    List<Employee> getAllEmployees() throws ClassNotFoundException, SQLException;
    String addEmployee(Employee employee) throws ClassNotFoundException, SQLException;
    String updateEmployee(Employee employee) throws ClassNotFoundException, SQLException;
    String removeEmployee(int employeeID) throws ClassNotFoundException, SQLException;
}
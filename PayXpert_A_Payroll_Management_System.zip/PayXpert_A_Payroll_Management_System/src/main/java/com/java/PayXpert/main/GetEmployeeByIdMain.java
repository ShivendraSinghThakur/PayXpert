package com.java.PayXpert.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.PayXpert.dao.EmployeeService;
import com.java.PayXpert.model.Employee;

public class GetEmployeeByIdMain {

	public static void main(String[] args) {
		int employeeID;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Employee Id: ");
		employeeID = sc.nextInt();
		
		EmployeeService e = new EmployeeService();
		
		try {
			Employee employee = e.getEmployeeById(employeeID);
			if(employee != null) {
				System.out.println(employee);
			}else {
				System.out.println("Employee Records Not Found");
			}
		} catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}

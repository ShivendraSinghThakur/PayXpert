package com.java.PayXpert.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.PayXpert.dao.TaxService;

public class GetTaxByIdMain {

	public static void main(String[] args) {
		int taxID;
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter taxID  ");
		
		taxID = sc.nextInt();
		TaxService t = new TaxService();
		
		try {
			double ans = t.getTaxById(taxID);
			if(ans == -1)
			{
				System.out.println("Record not found");
			}
			else
			{
				System.out.println("Tax Amount is " + ans);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

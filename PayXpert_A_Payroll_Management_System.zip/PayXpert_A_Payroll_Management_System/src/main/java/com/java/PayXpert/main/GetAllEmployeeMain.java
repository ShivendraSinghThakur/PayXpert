package com.java.PayXpert.main;

import java.sql.SQLException;
import java.util.List;

import com.java.PayXpert.dao.EmployeeService;
import com.java.PayXpert.model.Employee;

public class GetAllEmployeeMain {

	public static void main(String[] args) {
		EmployeeService e = new EmployeeService();
		
		try {
			List<Employee> employeeList = e.getAllEmployees();
			for(Employee employee : employeeList) {
				System.out.println(employee);
			}
		} catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}

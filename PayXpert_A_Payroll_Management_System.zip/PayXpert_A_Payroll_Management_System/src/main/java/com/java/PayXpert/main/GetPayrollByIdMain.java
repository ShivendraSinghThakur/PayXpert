package com.java.PayXpert.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.PayXpert.dao.PayrollService;
import com.java.PayXpert.model.Payroll;

public class GetPayrollByIdMain {

	public static void main(String[] args) {
		int payrollID;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter payrollID  ");
		
		payrollID = sc.nextInt();
		PayrollService p = new PayrollService();
		
		try {
			Payroll payroll = p.getPayrollById(payrollID);
			if(payroll != null) {
				System.out.println("Payroll Details  " + payroll);
			}
			else {
				System.out.println("Record Not Found");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

package com.java.PayXpert.dao;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import com.java.PayXpert.model.Payroll;

public interface IPayrollService {

	//void generatePayroll(int employeeID, Date startDate, Date endDate) throws ClassNotFoundException, SQLException;
    Payroll getPayrollById(int payrollID) throws ClassNotFoundException, SQLException;
    List<Payroll> getPayrollsForEmployee(int employeeID) throws ClassNotFoundException, SQLException;
    List<Payroll> getPayrollsForPeriod(Date payPeriodStartDate, Date payPeriodEndDate) throws ClassNotFoundException, SQLException;
	List<Payroll> generatePayroll(int employeeID, Date startDate, Date endDate) throws ClassNotFoundException, SQLException;
}

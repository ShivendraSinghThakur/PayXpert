package com.java.PayXpert.main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.java.PayXpert.dao.TaxService;
import com.java.PayXpert.model.Tax;

public class GetTaxesForEmployeeMain {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter employeeId  ");
		
		int employeeId = sc.nextInt();
		TaxService t = new TaxService();
		
		try {
			List<Tax> taxList = t.getTaxesForEmployee(employeeId);
			if(taxList != null)
			{
				for (Tax tax : taxList) {
					System.out.println(tax);
				}
			}
			if(taxList.size() == 0){
				System.out.println("Record Not Found  ");
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

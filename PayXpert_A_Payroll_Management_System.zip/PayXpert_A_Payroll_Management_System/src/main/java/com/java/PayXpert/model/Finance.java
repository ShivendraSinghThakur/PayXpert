package com.java.PayXpert.model;

import java.util.Date;
import java.util.Objects;

public class Finance {

	private int recordID;
	private int employeeID;
	private Date recordDate;
	private String description;
	private double amount;
	private String recordType;
	
	public int getRecordID() {
		return recordID;
	}
	public void setRecordID(int recordID) {
		this.recordID = recordID;
	}
	public int getEmployeeID() {
		return employeeID;
	}
	public void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}
	public Date getRecordDate() {
		return recordDate;
	}
	public void setRecordDate(Date recordDate) {
		this.recordDate = recordDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getRecordType() {
		return recordType;
	}
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}
	public Finance() {
		
	}
	public Finance(int recordID, int employeeID, Date recordDate, String description, double amount,
			String recordType) {
		this.recordID = recordID;
		this.employeeID = employeeID;
		this.recordDate = recordDate;
		this.description = description;
		this.amount = amount;
		this.recordType = recordType;
	}
	@Override
	public String toString() {
		return "Finance [recordID=" + recordID + ", employeeID=" + employeeID + ", recordDate=" + recordDate
				+ ", description=" + description + ", amount=" + amount + ", recordType=" + recordType + "]";
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(recordID, employeeID, recordDate, description , amount , recordType);
	}
	
	@Override
	public boolean equals(Object obj) {
		Finance f = (Finance)obj;
		if (f.getRecordID() == recordID && f.getEmployeeID() == employeeID 
            	&&f.getRecordDate().compareTo(recordDate) ==0 
			&& f.getDescription()==description
		&& f.getAmount()==amount && f.getRecordType()==recordType
				) {
			return true;
		}
		return false;
	}
	
	
}

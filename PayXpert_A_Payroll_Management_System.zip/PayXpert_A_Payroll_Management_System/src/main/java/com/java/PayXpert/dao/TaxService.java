package com.java.PayXpert.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.java.PayXpert.model.Payroll;
import com.java.PayXpert.model.Tax;
import com.java.PayXpert.util.DBConnUtil;
import com.java.PayXpert.util.DBPropertyUtil;

public class TaxService implements ITaxService{
	
	Connection connection;
	PreparedStatement pst;

	@Override
	public double CalculateTax(int employeeID, String year) throws ClassNotFoundException, SQLException {
		String connstr=DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connstr);
		
		String cmd1="select netsalary from payroll where employeeid=?";
		
		pst = connection.prepareStatement(cmd1);
		pst.setInt(1, employeeID);
		
		ResultSet rs=pst.executeQuery();
		
		Payroll payroll=null;
		if(rs.next()) {
			payroll=new Payroll();
			payroll.setNetSalary(rs.getDouble("netsalary"));

		}
		
	    String cmd2="select taxableincome from tax where employeeid=? and taxyear=?";
	    
	    pst=connection.prepareStatement(cmd2);
	    pst.setInt(1, employeeID);
	    pst.setString(2, year);
	    
	    Tax tax=null;
	    
	    rs=pst.executeQuery();
		
	    if(rs.next()) {
			tax=new Tax();
			tax.setTaxableIncome(rs.getDouble("taxableincome"));
		}
		
		return payroll.getNetSalary() - tax.getTaxableIncome();
	}

	@Override
	public double getTaxById(int taxID) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		
		String cmd = "SELECT * FROM Tax WHERE TaxID = ?";
		
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, taxID);
		
		ResultSet rs = pst.executeQuery();
		
		double a = -1;
		Tax tax = null;
		
		if(rs.next()) {
			tax = new Tax();
			tax.setTaxID(rs.getInt("TaxID"));
			tax.setEmployeeID(rs.getInt("EmployeeID"));
			tax.setYear(rs.getString("TaxYear"));
			tax.setTaxableIncome(rs.getDouble("TaxableIncome"));
			tax.setTaxAmount(rs.getDouble("TaxAmount"));
			int x = tax.getEmployeeID();
			String y = tax.getYear();
			return CalculateTax(x, y);
		}
		return a;
	}

	@Override
	public List<Tax> getTaxesForEmployee(int employeeID) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		
		String cmd = "SELECT * FROM Tax WHERE EmployeeID = ?";
		
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, employeeID);
		
		ResultSet rs = pst.executeQuery();
		
		List<Tax> taxes = new ArrayList<Tax>();
		Tax tax = null;
		
		while(rs.next()) {
			tax = new Tax();
			tax.setTaxID(rs.getInt("TaxID"));
			tax.setEmployeeID(rs.getInt("EmployeeID"));
			tax.setYear(rs.getString("TaxYear"));
			tax.setTaxableIncome(rs.getDouble("TaxableIncome"));
			tax.setTaxAmount(rs.getDouble("TaxAmount"));
			taxes.add(tax);
		}
		return taxes;
	}

	@Override
	public List<Tax> getTaxesForYear(String year) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		
		String cmd = "SELECT * FROM Tax WHERE TaxYear = ?";
		
		pst = connection.prepareStatement(cmd);
		pst.setString(1, year);
		
		ResultSet rs = pst.executeQuery();
		
		List<Tax> taxList = new ArrayList<Tax>();
		Tax tax = null;
		
		while(rs.next()) {
			tax = new Tax();
			tax.setTaxID(rs.getInt("TaxID"));
			tax.setEmployeeID(rs.getInt("EmployeeID"));
			tax.setYear(rs.getString("TaxYear"));
			tax.setTaxableIncome(rs.getDouble("TaxableIncome"));
			tax.setTaxAmount(rs.getDouble("TaxAmount"));
			taxList.add(tax);
		}
		return taxList;
	}

}
package com.java.PayXpert.main;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import com.java.PayXpert.dao.EmployeeService;
import com.java.PayXpert.model.Employee;

public class UpdateEmployeeMain {

	public static void main(String[] args) throws ParseException {
		Employee employ = new Employee();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter EmployeeID:  ");
		employ.setEmployeeId(sc.nextInt());
		System.out.println("Enter FirstName:  ");
		employ.setFirstName(sc.next());
		System.out.println("Enter LastName:  ");
		employ.setLastName(sc.next());
		System.out.println("Enter Dob:  ");
		String dateStr = sc.next();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date date = sdf.parse(dateStr);
		employ.setDob(date);
		System.out.println("Enter Gender:  ");
		employ.setGender(sc.next());
		System.out.println("Enter Email:  ");
		employ.setEmail(sc.next());
		System.out.println("Enter PhoneNumber:  ");
		employ.setPhoneNumber(sc.next());
		System.out.println("Enter Address:  ");
		employ.setAddress(sc.next());
		System.out.println("Enter Position:  ");
		employ.setPosition(sc.next());
		System.out.println("Enter JoiningDate:  ");
		employ.setJoiningDate(sc.next());
		System.out.println("Enter TerminationDate:  ");
		String terminationDateStr = sc.next();
		Date terminationDate = sdf.parse(terminationDateStr);
		employ.setTerminationDate(terminationDate);
		
		EmployeeService e = new EmployeeService();
		
		try {
			System.out.println(e.updateEmployee(employ));
		} catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}

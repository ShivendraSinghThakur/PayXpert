package com.java.PayXpert.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.PayXpert.dao.EmployeeService;

public class DeleteEmployeeMain {

	public static void main(String[] args) {
		int employeeId;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Employee ID: ");
		employeeId = sc.nextInt();
		EmployeeService e = new EmployeeService();
		try {
			System.out.println(e.removeEmployee(employeeId));
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
}

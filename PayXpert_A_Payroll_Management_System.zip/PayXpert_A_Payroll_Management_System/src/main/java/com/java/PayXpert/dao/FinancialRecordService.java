package com.java.PayXpert.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.java.PayXpert.model.Finance;
import com.java.PayXpert.util.DBConnUtil;
import com.java.PayXpert.util.DBPropertyUtil;

public class FinancialRecordService implements IFinancialRecordService{

	Connection connection;
	PreparedStatement pst;
	
	public int GenerateRecordId() throws ClassNotFoundException, SQLException {
		String connstr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connstr);
		String cmd = "Select max(recordid)+1 rid from finance";
		pst = connection.prepareStatement(cmd);
		ResultSet rs = pst.executeQuery();
		rs.next();
		int rid = rs.getInt("rid");
		return rid;
	}
	
	@Override
	public String addFinancialRecord(int employeeID, String description, double amount, String recordType)
			throws ClassNotFoundException, SQLException {
		
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		
		String cmd = "INSERT INTO Finance (EmployeeID, RecordDate, Descr, Amount, RecordType) VALUES (?, ?, ?, ?, ?)";
		
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, employeeID);
		pst.setDate(2, new  java.sql.Date(new java.util.Date().getTime()));
        pst.setString(3, description);
        pst.setDouble(4, amount);
        pst.setString(5, recordType);
        int rs = pst.executeUpdate();
        
        if(rs > 0)
		{
			return "Inserted successfully";
		}
		else
		{
			return "Record not found";
		}
		
	}

	@Override
	public Finance getFinancialRecordById(int recordID) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		
		String cmd = "SELECT * FROM Finance WHERE RecordID = ?";
		
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, recordID);
		
		ResultSet rs = pst.executeQuery();
		
		Finance record = null;
		
		if(rs.next()) {
			record = new Finance();
			record.setRecordID(rs.getInt("RecordID"));
			record.setEmployeeID(rs.getInt("EmployeeID"));
			record.setRecordDate(rs.getDate("RecordDate"));
			record.setDescription(rs.getString("Descr"));
			record.setAmount(rs.getDouble("Amount"));
			record.setRecordType(rs.getString("RecordType"));
		}
		return record;
	}

	@Override
	public List<Finance> getFinancialRecordsForEmployee(int employeeID) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		
		String cmd = "SELECT * FROM Finance WHERE EmployeeID = ?";
		
		pst = connection.prepareStatement(cmd);
		pst.setInt(1, employeeID);
		
		ResultSet rs = pst.executeQuery();
		
		List<Finance> records = new ArrayList<Finance>();
		Finance erecords = null;
		
		while(rs.next()) {
			erecords = new Finance();
			erecords.setRecordID(rs.getInt("RecordID"));
			erecords.setEmployeeID(rs.getInt("EmployeeID"));
			erecords.setRecordDate(rs.getDate("RecordDate"));
			erecords.setDescription(rs.getString("Descr"));
			erecords.setAmount(rs.getDouble("Amount"));
			erecords.setRecordType(rs.getString("RecordType"));
			records.add(erecords);
		}
		return records;
	}

	@Override
	public List<Finance> getFinancialRecordsForDate(Date recordDate) throws ClassNotFoundException, SQLException {
		String connStr = DBPropertyUtil.connectionString("db");
		connection = DBConnUtil.getConnection(connStr);
		
		String cmd = "SELECT * FROM Finance WHERE RecordDate = ?";
		
		pst = connection.prepareStatement(cmd);
		pst.setDate(1, new java.sql.Date(new java.util.Date().getTime()));
		
		ResultSet rs = pst.executeQuery();
		
		List<Finance> dateRecord = new ArrayList<Finance>();
		Finance drecord = null;
		
		while(rs.next()) {
			drecord = new Finance();
			drecord.setRecordID(rs.getInt("RecordID"));
			drecord.setEmployeeID(rs.getInt("EmployeeID"));
			drecord.setRecordDate(rs.getDate("RecordDate"));
			drecord.setDescription(rs.getString("Description"));
			drecord.setAmount(rs.getDouble("Amount"));
			drecord.setRecordType(rs.getString("RecordType"));
			dateRecord.add(drecord);
		}
		return dateRecord;
	}

}

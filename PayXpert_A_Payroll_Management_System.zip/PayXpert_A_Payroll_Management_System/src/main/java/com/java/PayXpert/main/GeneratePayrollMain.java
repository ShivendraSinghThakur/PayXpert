package com.java.PayXpert.main;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.java.PayXpert.dao.PayrollService;
import com.java.PayXpert.model.Payroll;

public class GeneratePayrollMain {

	public static void main(String[] args) throws ParseException {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter employeeID ");
		int employeeId = sc.nextInt();
		
		System.out.println("Enter payPeriodStartDate ");
		String sd = sc.next();
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date str = sdf.parse(sd);
		System.out.println("Enter payPeriodEndDate  ");
		String sd1 = sc.next();
		Date str1=sdf.parse(sd1);
		
		PayrollService p= new PayrollService();
		List<Payroll> payrollList = new ArrayList<Payroll>();
		
		try {
			payrollList =  p.generatePayroll(employeeId, str, str1);
			if(payrollList.size() > 0) {
				for (Payroll payroll : payrollList) {
					System.out.println(payroll);
				  }
				}
			   if(payrollList.size() == 0)
				{
					System.out.println("Record Not Found");
				}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

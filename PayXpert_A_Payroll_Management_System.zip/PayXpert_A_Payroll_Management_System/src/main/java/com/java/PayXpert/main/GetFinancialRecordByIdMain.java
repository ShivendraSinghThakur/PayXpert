package com.java.PayXpert.main;

import java.sql.SQLException;
import java.util.Scanner;

import com.java.PayXpert.dao.FinancialRecordService;
import com.java.PayXpert.model.Finance;

public class GetFinancialRecordByIdMain {
	
	public static void main(String[] args) {
		Finance finance = null;
		FinancialRecordService f =  new FinancialRecordService();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter RecordID  ");
		int recordId = sc.nextInt();
		
		try {
			finance = f.getFinancialRecordById(recordId);
			if(finance != null)
			{
				System.out.println(finance);
			}
			else
			{
				System.out.println("Record not found");
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

package com.java.PayXpert.model;

import java.util.Objects;

public class Tax {
	
	private int taxID;
	private int employeeID;
	private String year;
	private double taxableIncome;
	private double taxAmount;
	
	public int getTaxID() {
		return taxID;
	}
	public void setTaxID(int taxID) {
		this.taxID = taxID;
	}
	public int getEmployeeID() {
		return employeeID;
	}
	public void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public double getTaxableIncome() {
		return taxableIncome;
	}
	public void setTaxableIncome(double taxableIncome) {
		this.taxableIncome = taxableIncome;
	}
	public double getTaxAmount() {
		return taxAmount;
	}
	public void setTaxAmount(double taxAmount) {
		this.taxAmount = taxAmount;
	}
	public Tax() {
		
	}
	public Tax(int taxID, int employeeID, String year, double taxableIncome, double taxAmount) {
		this.taxID = taxID;
		this.employeeID = employeeID;
		this.year = year;
		this.taxableIncome = taxableIncome;
		this.taxAmount = taxAmount;
	}
	@Override
	public String toString() {
		return "Tax [taxID=" + taxID + ", employeeID=" + employeeID + ", year=" + year + ", taxableIncome="
				+ taxableIncome + ", taxAmount=" + taxAmount + "]";
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(taxID, employeeID, year,  taxableIncome ,taxAmount );
	}

}
